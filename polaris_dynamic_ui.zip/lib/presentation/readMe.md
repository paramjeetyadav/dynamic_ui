## THIS FOLDER CONTAINS UI ELEMENT, SCREEN AND CUBIT STATE MANAGEMENT

- **`screen`**:  contains whole page UI with its state management.
  - **`cubit`**:  contains state management for home,base and dynamic form.
- **`widgets`**: contains all smaller UI building blocks that are used inside screens.
