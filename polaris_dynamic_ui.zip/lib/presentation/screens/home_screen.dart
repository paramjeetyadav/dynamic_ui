import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:polaris/presentation/screens/cubit/base_view_model.dart';

import '../../data/model/form_model.dart';
import '../../data/network/network_service.dart';
import '../../infrastructure/routes/route_names.dart';
import '../../infrastructure/utils/dialog_helper.dart';
import '../screens/cubit/sync_view_model.dart';
import '../widgets/common_card_widget.dart';
import 'cubit/form_view_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _syncAnimController;
  late StreamController<NetworkStatus> _networkStream;
  @override
  void initState() {
    _syncAnimController = AnimationController(duration: const Duration(milliseconds: 800), vsync: this)
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          _syncAnimController.repeat(reverse: false);
        }
      });
    _networkStream = NetworkStatusService().networkStatusController;
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) async {
      _networkStream.stream.listen((event) {
        context.read<SyncViewModel>().syncData(context, event == NetworkStatus.Online);
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _syncAnimController.dispose();
    _networkStream.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        elevation: 5,
        title: const Text("Polaris Smart Metering"),
        centerTitle: false,
        actions: [
          Stack(
            children: [
              BlocBuilder<SyncViewModel, SyncState>(
                builder: (context, state) {
                  if (state.isLoading) {
                    _syncAnimController.forward();
                  }
                  if (!state.isLoading) {
                    _syncAnimController.stop();
                    _syncAnimController.reset();
                  }
                  return IconButton(
                    onPressed: () async {
                      if (!context.read<BaseViewModel>().state.isConnected) {
                        DialogHelper(context: context)
                            .showFlushBar(title: "No Internet", message: "Please connect to internet!", type: FlushBarType.error);
                        return;
                      }

                      if (state.isLoading) return;

                      await context.read<SyncViewModel>().syncData(context, true);
                    },
                    icon: RotationTransition(
                      turns: Tween(begin: 0.0, end: 1.0).animate(_syncAnimController),
                      child: const Icon(
                        Icons.sync,
                        size: 30,
                        color: Colors.white,
                      ),
                    ),
                  );
                },
              ),
              Positioned(
                top: 13,
                right: 13,
                child: Container(
                  height: 8,
                  width: 8,
                  decoration: BoxDecoration(
                    // color: Colors.greenAccent,
                    color: kIsWeb
                        ? Colors.green
                        : context.watch<NetworkStatus>() == NetworkStatus.Online
                            ? Colors.green.shade600
                            : Colors.red,
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: SizedBox(
        height: double.maxFinite,
        width: double.maxFinite,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: BlocBuilder<FormResponseViewModel, FormResponseState>(
            builder: (context, state) {
              return Visibility(
                visible: !state.isLoading,
                replacement: const RepaintBoundary(
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                ),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: state.formList.length,
                  itemBuilder: (context, index) {
                    FormModel formModel = state.formList[index];
                    return CommonCardWidget(
                      formModel: formModel,
                      onTap: () {
                        context.goNamed(RouteName.form, pathParameters: {"form": formModel.formName ?? ''});
                      },
                    );
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
