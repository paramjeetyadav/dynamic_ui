import 'package:flutter_bloc/flutter_bloc.dart';

class BaseState {
  final bool isLoading;
  final bool isConnected;
  final String selectedLanguage;
  final int currentBottomIndex;

  BaseState({
    this.isLoading = false,
    this.isConnected = false,
    this.selectedLanguage = "",
    this.currentBottomIndex = 0,
  });

  BaseState copyWith({
    bool? isLoading,
    bool? isConnected,
    String? selectedLanguage,
    int? currentBottomIndex,
  }) {
    return BaseState(
      isLoading: isLoading ?? this.isLoading,
      isConnected: isConnected ?? this.isConnected,
      selectedLanguage: selectedLanguage ?? this.selectedLanguage,
      currentBottomIndex: currentBottomIndex ?? this.currentBottomIndex,
    );
  }
}

class BaseViewModel extends Cubit<BaseState> {
  BaseViewModel() : super(BaseState()); // Initialize with default state values as defined in BaseState

  void setCurrentBottomIndex(int index) {
    emit(state.copyWith(currentBottomIndex: index));
  }

  void setLanguage(String code) {
    emit(state.copyWith(selectedLanguage: code));
  }

  void setConnectionStatus(bool status) {
    emit(state.copyWith(isConnected: status));
  }

  void toggleLoading([bool? value]) {
    emit(state.copyWith(isLoading: value ?? !state.isLoading));
  }
}
