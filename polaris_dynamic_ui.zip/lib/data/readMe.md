## THIS FOLDER CONTAINS ALL DATA EITHER PRESENT IN DATABASE OR CALL THROUGH NETWORK AND THERE RESPONSE MODEL(ENTITY)

- **`db`**:  DB contains all database query and creation of table.
- **`network`**:  Network responsible for all data fetch through API
- **`entity`**:  Entity contain all response models
