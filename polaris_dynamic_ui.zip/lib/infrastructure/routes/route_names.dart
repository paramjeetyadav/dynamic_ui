class RouteName {
  static const String home = "/home";
  static const String splash = "/";
  static const String form = "form";
  static const String formResponse = "form-response";
}
