package com.example.polaris

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
